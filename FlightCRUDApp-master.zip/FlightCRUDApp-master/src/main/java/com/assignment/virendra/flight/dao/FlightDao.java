package com.assignment.virendra.flight.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.assignment.virendra.flight.model.Flight;


public class FlightDao {
    private String jdbcURL = "jdbc:mysql://localhost:3306/flightdb";
    private String jdbcUsername = "root"; 
    private String jdbcPassword = "virensql"; 
    private String jdbcDriver = "com.mysql.cj.jdbc.Driver";

    private static final String INSERT_FLIGHT_SQL = "INSERT INTO flights (flight_no, airline, departure_city, arrival_city, departure_time) VALUES (?, ?, ?, ?, ?);";
    private static final String SELECT_FLIGHT_BY_ID = "SELECT id, flight_no, airline, departure_city, arrival_city, departure_time FROM flights WHERE id = ?;";
    private static final String SELECT_ALL_FLIGHTS = "SELECT * FROM flights;";
    private static final String DELETE_FLIGHT_SQL = "DELETE FROM flights WHERE id = ?;";
    private static final String UPDATE_FLIGHT_SQL = "UPDATE flights SET flight_no = ?, airline= ?, departure_city =?, arrival_city =?, departure_time =? WHERE id = ?;";

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName(jdbcDriver);
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void insertFlight(Flight flight) throws SQLException {
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_FLIGHT_SQL)) {
            preparedStatement.setString(1, flight.getFlightNo());
            preparedStatement.setString(2, flight.getAirline());
            preparedStatement.setString(3, flight.getDepartureCity());
            preparedStatement.setString(4, flight.getArrivalCity());
            preparedStatement.setTimestamp(5, Timestamp.valueOf(flight.getDepartureTime()));
            preparedStatement.executeUpdate();
        }
    }

    public boolean updateFlight(Flight flight) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE_FLIGHT_SQL);) {
            statement.setString(1, flight.getFlightNo());
            statement.setString(2, flight.getAirline());
            statement.setString(3, flight.getDepartureCity());
            statement.setString(4, flight.getArrivalCity());
            statement.setTimestamp(5, Timestamp.valueOf(flight.getDepartureTime()));
            statement.setInt(6, flight.getId());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public Flight selectFlight(int id) {
        Flight flight = null;
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_FLIGHT_BY_ID);) {
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String flightNo = rs.getString("flight_no");
                String airline = rs.getString("airline");
                String departureCity = rs.getString("departure_city");
                String arrivalCity = rs.getString("arrival_city");
                LocalDateTime departureTime = rs.getTimestamp("departure_time").toLocalDateTime();
                flight = new Flight(id, flightNo, airline, departureCity, arrivalCity, departureTime);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flight;
    }

    public List < Flight > selectAllFlights() {
        List < Flight > flights = new ArrayList < > ();
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_FLIGHTS);) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String flightNo = rs.getString("flight_no");
                String airline = rs.getString("airline");
                String departureCity = rs.getString("departure_city");
                String arrivalCity = rs.getString("arrival_city");
                LocalDateTime departureTime = rs.getTimestamp("departure_time").toLocalDateTime();
                flights.add(new Flight(id, flightNo, airline, departureCity, arrivalCity, departureTime));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flights;
    }

    public boolean deleteFlight(int id) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(DELETE_FLIGHT_SQL);) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }
}
