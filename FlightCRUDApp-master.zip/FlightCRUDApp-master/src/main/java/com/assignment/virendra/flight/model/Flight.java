package com.assignment.virendra.flight.model;


import java.time.LocalDateTime;

public class Flight {
    private int id;
    private String flightNo;
    private String airline;
    private String departureCity;
    private String arrivalCity;
    private LocalDateTime departureTime;

    // Constructors
    public Flight() {}

    public Flight(String flightNo, String airline, String departureCity, String arrivalCity, LocalDateTime departureTime) {
        super();
        this.flightNo = flightNo;
        this.airline = airline;
        this.departureCity = departureCity;
        this.arrivalCity = arrivalCity;
        this.departureTime = departureTime;
    }
    
    public Flight(int id, String flightNo, String airline, String departureCity, String arrivalCity, LocalDateTime departureTime) {
        super();
        this.id = id;
        this.flightNo = flightNo;
        this.airline = airline;
        this.departureCity = departureCity;
        this.arrivalCity = arrivalCity;
        this.departureTime = departureTime;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getFlightNo() {
        return flightNo;
    }
    public void setFlightNo(String flightNo) {
        this.flightNo = flightNo;
    }
    public String getAirline() {
        return airline;
    }
    public void setAirline(String airline) {
        this.airline = airline;
    }
    public String getDepartureCity() {
        return departureCity;
    }
    public void setDepartureCity(String departureCity) {
        this.departureCity = departureCity;
    }
    public String getArrivalCity() {
        return arrivalCity;
    }
    public void setArrivalCity(String arrivalCity) {
        this.arrivalCity = arrivalCity;
    }
    public LocalDateTime getDepartureTime() {
        return departureTime;
    }
    public void setDepartureTime(LocalDateTime departureTime) {
        this.departureTime = departureTime;
    }
}
