package com.assignment.virendra.flight.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.assignment.virendra.flight.dao.FlightDao;
import com.assignment.virendra.flight.model.Flight;

/**
 * Servlet implementation class FlightControllerServlet
 */
@WebServlet("/")
public class FlightControllerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private FlightDao flightDao;

    public void init() {
        flightDao = new FlightDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        String action = request.getServletPath();

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertFlight(request, response);
                    break;
                case "/delete":
                    deleteFlight(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateFlight(request, response);
                    break;
                default:
                    listFlight(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void listFlight(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException, ServletException {
        List < Flight > listFlight = flightDao.selectAllFlights();
        request.setAttribute("listFlight", listFlight);
        RequestDispatcher dispatcher = request.getRequestDispatcher("flight-list.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("flight-form.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Flight existingFlight = flightDao.selectFlight(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("flight-form.jsp");
        request.setAttribute("flight", existingFlight);
        dispatcher.forward(request, response);
    }

    private void insertFlight(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException {
        String flightNo = request.getParameter("flightNo");
        String airline = request.getParameter("airline");
        String departureCity = request.getParameter("departureCity");
        String arrivalCity = request.getParameter("arrivalCity");
        LocalDateTime departureTime = LocalDateTime.parse(request.getParameter("departureTime"), DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        
        Flight newFlight = new Flight(flightNo, airline, departureCity, arrivalCity, departureTime);
        flightDao.insertFlight(newFlight);
        response.sendRedirect("list");
    }

    private void updateFlight(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String flightNo = request.getParameter("flightNo");
        String airline = request.getParameter("airline");
        String departureCity = request.getParameter("departureCity");
        String arrivalCity = request.getParameter("arrivalCity");
        LocalDateTime departureTime = LocalDateTime.parse(request.getParameter("departureTime"), DateTimeFormatter.ISO_LOCAL_DATE_TIME);

        Flight flight = new Flight(id, flightNo, airline, departureCity, arrivalCity, departureTime);
        flightDao.updateFlight(flight);
        response.sendRedirect("list");
    }

    private void deleteFlight(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        flightDao.deleteFlight(id);
        response.sendRedirect("list");
    }
}